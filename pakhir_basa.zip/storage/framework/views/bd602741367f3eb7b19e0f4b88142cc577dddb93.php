
<?php $__env->startSection('title', 'Company Profile Edit'); ?>
<?php $__env->startSection('admin-content'); ?>
<main>
   <div class="container ">
    <div class="heading-title p-2 my-2">
        <span class="my-3 heading "><i class="fas fa-home"></i> <a class="" href="<?php echo e(route('admin.index')); ?>">Home</a> >Company Profile Edit</span>
    </div>
    <div class="card mb-3">
        <div class="card-header">
            <i class="fas fa-user-plus"></i>
            Company Profile
        </div>
        <div class="card-body table-card-body p-3 mytable-body">
            <form action="<?php echo e(route('profile.update', $company)); ?>" method="post" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <?php echo method_field('put'); ?>
                <div class="row">
                     <div class="col-md-6">
                         <div class="row">
                            <div class="col-md-3">
                                <strong><label>Name</label> <span class="float-right">:</span></strong>
                             </div>
                            <div class="col-md-9">
                                 <input type="text" name="company_name" value="<?php echo e($company->company_name); ?>" class="form-control my-form-control <?php $__errorArgs = ['company_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                 <?php $__errorArgs = ['company_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                 <span class="invalid-feedback" role="alert">
                                     <strong><?php echo e($message); ?></strong>
                                 </span> 
                                 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> 
                             </div> 
                             <div class="col-md-3">
                                <strong><label>Email</label> <span class="float-right">:</span></strong>
                            </div>
                             <div class="col-md-9">
                                <input type="email" name="email" value="<?php echo e($company->email); ?>" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> my-form-control" >
                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span> 
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                             </div> 
                             <div class="col-md-3">
                                <strong><label>Phone 1</label> <span class="float-right">:</span></strong>
                            </div>
                             <div class="col-md-9">
                                <input type="text" name="phone_1" value="<?php echo e($company->phone_1); ?>" class="form-control <?php $__errorArgs = ['phone_1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> my-form-control" >
                               <?php $__errorArgs = ['phone_1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                   <span class="invalid-feedback" role="alert">
                                       <strong><?php echo e($message); ?></strong>
                                   </span>
                               <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                             </div> 
                             <div class="col-md-3">
                                <strong><label>Phone 2</label> <span class="float-right">:</span></strong>
                            </div>
                             <div class="col-md-9">
                                <input type="text" name="phone_2" value="<?php echo e($company->phone_2); ?>" class="form-control my-form-control" >
                             </div> 



                             


                            <div class="col-md-3">
                                <strong><label>Address</label> <span class="float-right">:</span></strong>
                            </div>
                            <div class="col-md-9">
                                <textarea rows="4"  class="form-control <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> " name="address" ><?php echo $company->address; ?>

                                </textarea>
                                <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div> 
                         </div>
                     </div>
                     <div class="col-md-6">
                        <div class="row right-row">
                            
                            <div class="col-md-4">
                                <strong><label>Facebook Link</label> <span class="float-right">:</span></strong>
                            </div>
                            <div class="col-md-8">
                                <input type="text" value="<?php echo e($company->facebook); ?>" name="facebook" class="form-control my-form-control" >
                            </div>
                            <div class="col-md-4">
                                <strong><label>Youtube Link</label> <span class="float-right">:</span></strong>
                            </div>
                            <div class="col-md-8">
                                <input type="text" value="<?php echo e($company->youtube); ?>" name="youtube" class="form-control my-form-control" >
                                <?php if($errors->has('address')): ?>
                                    <span class="text-danger"><?php echo e($errors->first('address')); ?></span>
                                <?php endif; ?>
                            </div>
                            <div class="col-md-4">
                                <strong><label>Linkedin Link</label> <span class="float-right">:</span></strong>
                            </div>
                            <div class="col-md-8">
                                <input type="text" value="<?php echo e($company->linkedin); ?>"  name="linkedin" class="form-control my-form-control" >
                            </div>
                            <div class="col-md-4">
                                <strong><label>Instagram Link</label> <span class="float-right">:</span></strong>
                            </div>
                            <div class="col-md-8">
                                <input type="text" value="<?php echo e($company->instagram); ?>" name="instagram" class="form-control my-form-control" >
                            </div>
                            
                           
                            <div class="col-md-4">
                                <strong><label>Logo</label> <span class="float-right">:</span></strong>
                            </div>
                             <div class="col-md-6">
                                <input type="file" class="form-control my-form-control <?php $__errorArgs = ['logo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> " id="image" name="logo" onchange="readURL(this);">
                                <?php $__errorArgs = ['logo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-md-2 ps-0">
                                <img class="form-controlo img-thumbnail w-100" src="#" id="previewImage" style="height:80px; background: #3f4a49;">
                            </div>
                            
                            <div class="col-md-12">
                                <button type="submit" class="btn btn-primary btn-sm mt-2 float-right" value="Submit">Update</button>
                            </div>
                        </div>
                    </div>  
                </div>
            </form>
        </div>
   </div>
      
    </div>
</main>        
<?php $__env->stopSection(); ?>
<?php $__env->startPush('admin-js'); ?>
<script>
    // summernote 
    $(document).ready(function(){
      $('#address').summernote({
              tabsize: 2,
              height: 50
          });
    });
</script>
<script> 
function readURL(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();
            reader.onload=function(e) {
                $('#previewImage')
                    .attr('src', e.target.result)
                    .width(100);
                   
            };
            reader.readAsDataURL(input.files[0]);
        }
    }
    document.getElementById("previewImage").src="<?php echo e(asset($company->logo)); ?>";
    
</script> 

<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\zenevia\resources\views/admin/content/profile.blade.php ENDPATH**/ ?>