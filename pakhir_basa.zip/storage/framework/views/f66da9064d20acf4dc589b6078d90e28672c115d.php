
<?php $__env->startSection('title', 'All Order'); ?>
<?php $__env->startSection('admin-content'); ?>
<main>
    <div class="container">
        <div class="heading-title p-2 my-2">
            <span class="my-3 heading "><i class="fas fa-home"></i> <a class="" href="<?php echo e(route('admin.index')); ?>">Home</a> >Order List</span>
        </div>
        <div class="card">
            <div class="card-header">
                <div class="table-head text-left"><i class="fas fa-table me-1"></i>Pending Order List <a href="" class="float-right"><i class="fas fa-print"></i></a></div>
                
            </div>
            <div class="card-body table-card-body p-3">
                <div class="tab-content" id="myTabContent">
                  <div class="tab-pane fade show active" id="pending" role="tabpanel" aria-labelledby="home-tab">
                       <table id="first_table">
                        <thead class="text-center bg-light">
                            <tr>
                                <th>Invoice No.</th>
                                <th>Date</th>
                                <th>Customer Id</th>
                                <th>Delivery Date & Time</th>
                                <th>Customer Name</th>
                                <th>Price</th>
                                <th>Status</th>
                                <th width="10%">Action</th>
                            </tr>
                        </thead>
                       <tbody>
                        
                            <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=> $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="text-center">
                                <td><?php echo e($order->invoice_no); ?></td>
                                <td><?php echo e(date('d M Y',strtotime($order->created_at))); ?></td>
                                <td><?php if(isset($order->customer->code)): ?><?php echo e($order->customer->code); ?><?php endif; ?></td>
                                <td><?php if(isset($order->delivery_date)): ?><?php echo e($order->delivery_date); ?> <?php endif; ?> ,<?php if(isset($order->deliveryTime->time)): ?> <?php echo e($order->deliveryTime->time); ?> <?php endif; ?></td>
                                <td><?php if(isset($order->customer_name)): ?><?php echo e($order->customer_name); ?><?php endif; ?></td>
                                <td><?php echo e($order->total_amount); ?></td>
                                <td>
                                    <?php if($order->status == 'p'): ?>
                                    <a href="<?php echo e(route('order.pending',$order->id)); ?>" onclick="return confirm('are you sure! Order on process')" class="btn btn-edit">Pending</a>
                                    <?php endif; ?>
                                </td>
                                <td class="text-center">
                                    <!--<a href="<?php echo e(route('invoice.admin',$order->id)); ?>" class="btn btn-edit" title="View"><i class="fas fa-eye"></i></a>-->
                                    <!--<a href="<?php echo e(route('order.details.edit',$order->id)); ?>" class="btn btn-edit" title="Edit"><i class="fas fa-edit"></i></a>-->
                                   
                                   <form action="<?php echo e(route('product.order.delete',$order->id)); ?>" method="post">
                                        <?php echo csrf_field(); ?>
                                        <a href="<?php echo e(route('invoice.admin',$order->id)); ?>" class="btn btn-edit"><i class="fas fa-eye"></i></a>
                                        <a href="<?php echo e(route('order.details.edit',$order->id)); ?>" class="btn btn-edit" title="Edit"><i class="fas fa-edit"></i></a>
                                        <button href="" type="submit" class="btn btn-delete" title="Cancel" onclick="return confirm('Are you sure you want to cancel this order?');"><i class="fas fa-window-close"></i></button>
                                    </form>
                                   
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            
                        </tbody>
                    </table>
                  </div>
                 
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\zenevia-01-02-22\resources\views/admin/order/index.blade.php ENDPATH**/ ?>