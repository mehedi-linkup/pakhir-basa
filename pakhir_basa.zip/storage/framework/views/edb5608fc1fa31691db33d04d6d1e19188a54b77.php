
<?php $__env->startSection('title', 'Pending Order'); ?>
<?php $__env->startSection('admin-content'); ?>
<main>
    <div class="container">
        <div class="heading-title p-2 my-2">
            <span class="my-3 heading "><i class="fas fa-home"></i> <a class="" href="<?php echo e(route('admin.index')); ?>">Home</a> >Delivary List</span>
        </div>
        <div class="card">
            <div class="card-header d-flex">
                <div class="table-head text-left"><i class="fas fa-table me-1"></i>Deleverd Order List</div>
                <div class="mx-5"><b>Total: <?php echo e($total); ?></b></div>
            </div>
            <div class="card-body table-card-body p-3">
                <div class="tab-content" id="myTabContent">
                  <div class="tab-pane fade show active" id="pending">
                    <table id="first_table">
                        <thead class="text-center bg-light">
                            <tr>
                                <th>Invoice No.</th>
                                <th>Order Date</th>
                                <th>Delivary Date</th>
                                <th>Customer Id</th>
                                <th>Customer Name</th>
                                <th>Username</th>
                                <th>Delivery Date & Time</th>
                                <th>Price</th>
                                <th>Status</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=> $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="text-center">
                                <td><?php echo e($order->invoice_no); ?></td>
                                <td><?php echo e(date('d M Y',strtotime($order->created_at))); ?></td>
                                <td><?php echo e(date('d M Y',strtotime($order->updated_at))); ?></td>
                                <td><?php if(isset($order->customer->code)): ?><?php echo e($order->customer->code); ?><?php endif; ?></td>
                                <td><?php if(isset($order->customer_name)): ?><?php echo e($order->customer_name); ?><?php endif; ?></td>
                                <td><?php if(isset($order->user->name)): ?><?php echo e($order->user->name); ?><?php endif; ?></td>
                                <td><?php if(isset($order->delivery_date)): ?><?php echo e($order->delivery_date); ?> <?php endif; ?> ,<?php if(isset($order->deliveryTime->time)): ?> <?php echo e($order->deliveryTime->time); ?> <?php endif; ?></td>
                                
                                <td><?php echo e($order->total_amount); ?></td>
                                <td>
                                    <?php if($order->status == 'd'): ?>
                                    <button class="btn btn-edit" disabled>Delivered</button>
                                    <?php endif; ?>
                                </td>
                                <td class="text-center">
                                    <?php if(Auth::user()->action_view == 1): ?>
                                        <a href="<?php echo e(route('invoice.admin',$order->id)); ?>" class="btn btn-edit"><i class="fas fa-eye"></i></a>
                                    <?php endif; ?>
                                    <?php if(Auth::user()->action_delete == 1): ?>
                                        <button class="btn btn-delete" disabled><i class="fa fa-trash"></i></button>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                  </div>
                 
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/dewbxcak/zeneviaexpress.com/resources/views/admin/order/delivered.blade.php ENDPATH**/ ?>