
<?php $__env->startSection('website-content'); ?>

 <!-- Start of Breadcrumb -->
<nav class="breadcrumb-nav container">
    <ul class="breadcrumb bb-no">
        <li><a href="<?php echo e(route('home')); ?>">Home</a></li>
        <li>Search</li>
    </ul>
</nav>
<!-- End of Breadcrumb -->
 <!-- Start of PageContent -->
 <div class="page-content">
    <div class="container">
        <?php if($search_result->count() > 0): ?>
        <div class="product-wrapper row cols-md-1 cols-xs-2 cols-1">
            <?php $__currentLoopData = $search_result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="product product-list">
                <figure class="product-media">
                    <a href="product-default.html">
                        <img src="<?php echo e(asset('uploads/product/'.$item->image)); ?>" alt="<?php echo e($item->name); ?>" width="330"
                            height="338" />
                    </a>
                    <div class="product-action-vertical">
                        <a href="#" class="btn-product-icon btn-quickview w-icon-search"
                            title="Quick View"></a>
                    </div>
                </figure>
                <div class="product-details">
                    <div class="product-cat">
                        <a href="shop-banner-sidebar.html"><?php echo e(@$item->category ? $item->category->name : ''); ?></a>
                    </div>
                    <h4 class="product-name">
                        <a href="product-default.html"><?php echo e($item->name); ?></a>
                    </h4>
                    
                    <div class="product-price"><?php echo e($item->price); ?></div>
                    <ul class="product-desc">
                        <?php echo $item->short_details; ?>

                    </ul>
                    <div class="product-action">
                        <a href="#" class="btn-product btn-cart" title="Add to Cart"><i
                                class="w-icon-cart"></i> Add To Cart</a>
                        <a href="#" class="btn-product-icon btn-wishlist w-icon-heart"
                            title="Add to wishlist"></a>
                        <a href="#" class="btn-product-icon btn-compare w-icon-compare"
                            title="Compare"></a>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                   
        </div>
        <?php else: ?>
        <h2 class="text-danger text-center">Sorry! Product has no found</h2>
        <?php endif; ?>
    </div>
</div>
<!-- End of PageContent -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.website', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\mehedi\pakhir_basa\resources\views/website/search.blade.php ENDPATH**/ ?>