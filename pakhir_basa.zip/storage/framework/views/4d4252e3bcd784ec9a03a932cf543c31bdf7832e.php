
<?php $__env->startSection('title', 'Product Order Details'); ?>
<?php $__env->startSection('admin-content'); ?>
<main>
    <div class="container">
        <div class="heading-title p-2 my-2">
            <span class="my-3 heading "><i class="fas fa-home"></i> <a class="" href="<?php echo e(route('admin.index')); ?>">Home</a> >Product Order Details</span>
        </div>
        <div class="card">
            <div class="card-header">
                <table class="table" style="background: #fff">
                    <thead class="text-center order-table">
                        <tr>
                            <th>SL</th>
                            <th>Product Name</th>
                            <th>Quantity</th>
                            <th>Color </th>
                            <th>Size</th>
                            <th>Amount</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody class="text-center">
                        <?php $__currentLoopData = $orderDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=> $d_order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <form action="<?php echo e(route('order.edit',$d_order->id)); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="id" id="<?php echo e($orderDetails['0']->order->id); ?>" value="<?php echo e($orderDetails['0']->order->id); ?>" >
                                <tr>
                                    <td><?php echo e($key+1); ?></td>
                                    <td><?php echo e($d_order->product->name); ?></td>
                                    <td>
                                        <input id=demoInput name="quantity" type='number' min='1'  max='110' value="<?php echo e($d_order->quantity); ?>" >
                                    </td>
                                    <td>
                                        <select name="color_id" id="color_id" class=" form-control  mr-2" data-live-search="true">
                                            <option value="">Select Color</option>
                                            <?php $__currentLoopData = $colors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $color): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($color->id); ?>" <?php echo e($color->id == $d_order->color_id ? 'selected' : ''); ?>><?php echo e($color->name); ?></option>  
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </td>
                                    <td>
                                        <select name="size_id" id="size" class=" form-control  mr-2" data-live-search="true" >
                                            <option value="">Select Size</option>
                                            <?php $__currentLoopData = $sizes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $size): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($size->id); ?>" <?php echo e($size->id == $d_order->size_id ? 'selected' : ''); ?>><?php echo e($size->name); ?></option>  
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </td>
                                    <td><?php echo e($d_order->total_price); ?> </td>
                                    <td>
                                        <button type="submit" class="btn btn-edit mr-1" title="Save"><i class="fas fa-save"></i></button>
                                        <a href="<?php echo e(route('order.product.delete',$d_order->id)); ?>" title="Delete" onclick="return confirm('Are you sure! Delete this data')" class="btn btn-delete" ><i class="fas fa-trash"></i></a>
                                     </td>
                                </tr>
                            </form>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('admin-js'); ?>

 <script src="<?php echo e(asset('admin/js/sweetalert2.all.js')); ?>"></script>
 <script>
      $.ajaxSetup({
    headers: {
        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });
    
       
 </script>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/dewbxcak/zeneviaexpress.com/resources/views/admin/order/details.blade.php ENDPATH**/ ?>