
<?php $__env->startSection('website-content'); ?>
    <div class="container">
        <h2 class="text-center text-success py-3">Order Details</h2>
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="card mb-5">
                    <div class="card-body">
                        <div class="">
                            <div class="order_details d-flex w-100">
                                <span class="">Order No.</span> <span
                                    class=" ms-auto"><?php echo e($invoice->invoice_no); ?></span>
                            </div>
                            <div class="order_details d-flex w-100">
                                <span class="">Customer Name</span>
                                <?php if(isset($invoice->customer)): ?>
                                    <span class=" ms-auto"><?php echo e($invoice->customer->name); ?></span>
                                <?php endif; ?>
                            </div>
                            <div class="order_details d-flex w-100">
                                <span class="">Order From.</span> <span
                                    class="ms-auto"><?php echo e($invoice->billing_address); ?></span>
                            </div>
                            <div class="order_details d-flex w-100">
                                <span class="">Order Shipping Address.</span> <span class="ms-auto">
                                    <?php if(isset($invoice->shipping_address)): ?>
                                        <?php echo e($invoice->shipping_address); ?>

                                    <?php endif; ?>
                                </span>
                            </div>
                            <div class="w-100" style="border-bottom: 1px dotted#000;width:100%"></div>
                            <?php $__currentLoopData = $order; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="d-flex w-100 order_details">
                                    <span class="me-2"> <?php echo e($item->quantity); ?>x</span>
                                    <span><?php echo e($item->product_name); ?></span> <span
                                        class="ms-auto"><?php echo e((int) $item->price * $item->quantity); ?> Tk</span>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <div class="order_details d-flex w-100">
                                <span>Sub Total</span> <span
                                    class="ms-auto"><?php echo e((int) $invoice->total_amount - $invoice->shipping_cost); ?>

                                    Tk</span>
                            </div>
                            <div class="order_details d-flex w-100">
                                <span class="">Delivery Charge.</span> <span
                                    class="ms-auto"><?php echo e($invoice->shipping_cost); ?> Tk</span>
                            </div>
                            <div class="w-100" style="border-bottom: 1px dotted#000;width:100%"></div>
                            <div class="order_details d-flex w-100">
                                <span class="total_btn fw-bolder">Total</span> <span
                                    class="ms-auto fw-bolder"><?php echo e($invoice->total_amount); ?> Tk</span>
                            </div>
                        </div>
                        <div class="mt-3">

                       
                        <?php if(isset($invoice->pending_msg)): ?>
                            <p> <b>Process Message :</b> <?php echo e($invoice->pending_msg); ?></p>
                        <?php endif; ?>
                        <?php if(isset($invoice->process_msg)): ?>
                            <p> <b>On Process Message Message :</b> <?php echo e($invoice->process_msg); ?></p>
                        <?php endif; ?>
                        <?php if(isset($invoice->way_msg)): ?>
                            <p> <b>On the Way Message :</b> <?php echo e($invoice->way_msg); ?></p>
                        <?php endif; ?>
                        <?php if(isset($invoice->cancel_msg)): ?>
                            <p> <b>Cancel Message :</b> <?php echo e($invoice->cancel_msg); ?></p>
                        <?php endif; ?> </div>
                    </div>

                </div>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.website', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/dewbxcak/zeneviaexpress.com/resources/views/website/customer/customer_invoice.blade.php ENDPATH**/ ?>