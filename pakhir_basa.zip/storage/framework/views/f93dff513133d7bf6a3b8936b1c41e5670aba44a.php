
<?php $__env->startSection('title', 'DataTable'); ?>
<?php $__env->startSection('admin-content'); ?>
<?php $__env->startPush('admin-css'); ?>
<style>
    .dataTable-table th a {
    text-decoration: none;
    color: inherit;
    text-align: left;
}
.dataTable-table th a:nth-last-child() {
    text-decoration: none;
    color: inherit;
    text-align: center;
}
</style>
<?php $__env->stopPush(); ?>
<main>
   <div class="container ">
    <div class="heading-title p-2 my-2">
        <span class="my-3 heading "><i class="fas fa-home"></i> <a class="" href="<?php echo e(route('admin.index')); ?>">Home</a> >Area</span>
    </div>
    <form action="#" method="post" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="row">
                    <div class="col-md-12">
                        <div class="card"> 
                            <div class="card-header">
                                <div class="table-head"><i class="fas fa-table me-1"></i>Area List <a href="" class="float-right"><i class="fas fa-print"></i></a></div>
                            </div>
                            <div class="card-body table-card-body p-3">
                                <div class="tab-content" id="myTabContent">
                                  <div class="tab-pane fade show active" id="pending" role="tabpanel" aria-labelledby="home-tab">
                                       <table id="first_table">
                                        <thead class=" bg-light">
                                            <tr>
                                                <th width="10%">SL</th>
                                                <th>Email</th>
                                                <th width="10%">Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $subscriber; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=> $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($key+1); ?></td>
                                                <td><?php echo e($item->email); ?></td>
                                                <td class="text-center">
                                                    <a href="" class="btn btn-delete"><i class="fa fa-trash"></i></a>
                                                </td>
                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                  </div>
                                 
                            </div>
                        </div>
                    </div>
                </div>
            </form> 
    </div>
</main>        
<?php $__env->stopSection(); ?>
<?php $__env->startPush('admin-js'); ?>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\mehedi\pakhir_basa\resources\views/admin/subscriber/index.blade.php ENDPATH**/ ?>