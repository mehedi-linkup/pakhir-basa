
<?php $__env->startSection('title', 'SMS Sending'); ?>
<?php $__env->startSection('admin-content'); ?>
<main>
   <div class="container ">
    <div class="heading-title p-2 my-2">
        <span class="my-3 heading "><i class="fas fa-home"></i> <a class="" href="<?php echo e(route('admin.index')); ?>">Home</a> >Sent SMS to Customers</span>
    </div>
    
                <div class="row">
                    <form action="<?php echo e(route('sent.sms.multiple')); ?>" method="post" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                    <div class="col-md-6">
                        <div class="card">
                            <div class="card-header">
                                <div class=""><i class="fas fa-envelope me-1"></i>SMS Sent</div>
                            </div>
                            <div class="card-body table-card-body">
                                <div class="row">
                                    <div class="col-md-12">
                                      <textarea class="form-control" name="sms" rows="7" placeholder="Enter your Message"></textarea>
                                    </div> 
                                </div>
                                <div class="row">
                                    <div class="col-md-12 text-center">
                                        <button type="submit" class="btn btn-primary btn-sm mt-2 float-right" value="Submit">Sent</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                    </div>
                   
                    <div class="col-md-12 mt-3">
                        <div class="card"> 
                            <div class="card-header">
                                <div class="table-head"><i class="fas fa-table me-1"></i>Customer List <a href="" class="float-right"><i class="fas fa-print"></i></a></div>
                            </div>
                            <div class="card-body table-card-body p-3">
                                
                                <input id="selectAll" class="text-center" type="checkbox"> <label for='selectAll'> Select All</label>
                                <br/>
                                <br/>
                                <table id="first_table" class="text-center">
                                    <thead class="text-center bg-light">
                                        <tr>
                                            <th width="10%">SL</th>
                                            <th>Customer ID</th>
                                            <th>Customer Name</th>
                                            <th>Mobile No.</th>
                                            <th>Address</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><input class="form-check-input-2" name="customer_id[]"   type="checkbox" value="<?php echo e((int)$customer->id); ?>" id="flexCheckDefault"/></td>
                                            <td><?php echo e($customer->code); ?></td>
                                            <td><?php echo e($customer->name); ?></td>
                                            <td><?php echo e($customer->phone); ?></td>
                                            <td><?php echo e($customer->address); ?></td>
                                            <td><a href="<?php echo e(route('customer.deactive',$customer->id)); ?>" class="btn btn-sm btn-primary">Active</a></td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </form>
                </div>
           
    </div>
</main>        
<?php $__env->stopSection(); ?>
<?php $__env->startPush('admin-js'); ?>
<script src="<?php echo e(asset('admin/js/ckeditor.js')); ?>"></script>
<script>
    ClassicEditor
        .create( document.querySelector( '#short_details' ) )
        .catch( error => {
            console.error( error );
        } );
        
</script>
<script>
    ClassicEditor
        .create( document.querySelector( '#details' ) )
        .catch( error => {
            console.error( error );
        } );
        
</script>
<script> 
function readURL(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();
            reader.onload=function(e) {
                $('#previewImage')
                    .attr('src', e.target.result)
                    .width(100);
                   
            };
            reader.readAsDataURL(input.files[0]);
        }
    }
    document.getElementById("previewImage").src="/noimage.png";
    
</script> 
<script> 
    $("#selectAll").click(function() {
  $("input[type=checkbox]").prop("checked", $(this).prop("checked"));
});

$("input[type=checkbox]").click(function() {
  if (!$(this).prop("checked")) {
    $("#selectAll").prop("checked", false);
  }
});

jackHarnerSig();
</script> 

<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/dewbxcak/zeneviaexpress.com/resources/views/admin/sms_sending/sms.blade.php ENDPATH**/ ?>