
<?php $__env->startSection('title', 'Sales Order'); ?>
<?php $__env->startSection('admin-content'); ?>
    <main>
        <div class="container">
            <div class="heading-title p-2 my-2">
                <span class="my-3 heading "><i class="fas fa-home"></i> <a class=""
                        href="<?php echo e(route('admin.index')); ?>">Home</a> >Sales report</span>
            </div>
            <div class="card">
                <div class="card-header">
                    <div class="table-head text-left"><i class="fas fa-table me-1"></i>Sales Report <a href=""
                            class="float-right"><i class="fas fa-print"></i></a></div>
                </div>
                <div class="card-body">

                    <form action="<?php echo e(route('sales.report')); ?>" method="get">
                        <div class="row">
                            <div class="col-3">
                                <select class="form-control form-control-sm" name="type">
                                    <option value="2">Without Details</option>
                                    <option value="1">With Details</option>
                                </select>
                            </div>
                            <div class="col-3">
                                <input type="date" name="start_date" value="<?php echo date('Y-m-d'); ?>"  class="form-control <?php $__errorArgs = ['start_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                <?php $__errorArgs = ['start_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <?php echo e($message); ?>

                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-3">
                                <input type="date" name="end_date" value="<?php echo date('Y-m-d'); ?>" class="form-control <?php $__errorArgs = ['end_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                <?php $__errorArgs = ['end_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <?php echo e($message); ?>

                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-3">
                                <button class="btn  btn-primary btn-sm" type="submit">search</button>
                            </div>
                        </div>
                    </form>
                </div>
                <div class="card-body table-card-body p-3">
                    <div class="tab-content" id="myTabContent">
                        <div class="tab-pane fade show active" id="pending" role="tabpanel" aria-labelledby="home-tab">
                            <table id="first_table">
                                <thead class="text-center bg-light">
                                    <tr>
                                        <th class="text-nowrap">Invoice Number</th>
                                        <th class="text-nowrap">Delivary Date</th>
                                        <th class="text-nowrap">Customer Id</th>
                                        <th class="text-nowrap">Customer Name</th>
                                        <th class="text-nowrap">Mobile No.</th>
                                        <th class="text-nowrap">Total Price</th>
                                        <?php if($type == 1): ?>
                                        <th>Product</th>
                                        <th>Quantity</th>
                                        <th class="text-nowrap">Unit Price</th>
                                        <th>Subtotal</th>
                                        <?php endif; ?>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                
                                <tbody>
                               
                                    
                                    <?php if($search->count() > 0): ?>
                                        <?php if($type == 1): ?>
                                            <?php $__currentLoopData = $search; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr class="text-center">
                                                    <td><?php echo e($order->invoice_no); ?></td>
                                                    <td><?php echo e(date('d M Y', strtotime($order->updated_at))); ?></td>
                                                    <td><?php if(isset($order->customer->code)): ?><?php echo e($order->customer->code); ?><?php endif; ?></td>
                                                   <td><?php if(isset($order->customer_name)): ?><?php echo e($order->customer_name); ?><?php endif; ?></td>
                                                   <td><?php if(isset($order->customer_mobile)): ?><?php echo e($order->customer_mobile); ?><?php endif; ?></td>
                                                    <td class="text-right text-nowrap"><?php echo e($order->total_amount); ?> Tk</td>
                                                    <td class="text-left p-1"><?php echo e($order->orderDetails[0]->product_name); ?></td>
                                                    <td class="p-1 text-center">
                                                        <?php echo e($order->orderDetails[0]->quantity); ?> 
                                                       
                                                    </td>
                                                    <td class="p-1 text-right text-nowrap">
                                                        <?php echo e($order->orderDetails[0]->price); ?> Tk</td>
                                                    <td class="p-1 text-right text-nowrap"><?php echo e($order->orderDetails[0]->total_price); ?> Tk</td>
                                                    <td class="text-center">
                                                        <a href="<?php echo e(route('invoice.admin', $order->id)); ?>"
                                                            class="btn btn-edit"><i class="fas fa-eye"></i></a>
                                                        <a href="<?php echo e(route('order.cancel', $order->id)); ?>"
                                                            class="btn btn-delete"><i class="fa fa-trash"></i></a>
                                                    </td>
                                                </tr>
                                                
                                                <?php if($order->orderDetails->count() > 0): ?>
                                                    <?php $__currentLoopData = $order->orderDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php if($loop->iteration != 1): ?>
                                                            <tr>
                                                                <td colspan="6"></td>
                                                                <td class="text-left p-1"><?php echo e($item->product_name); ?></td>
                                                                <td class="p-1 text-center">
                                                                    <?php echo e($item->quantity); ?> 
                                                                </td>
                                                                <td class="p-1 text-right text-nowrap"><?php echo e($item->price); ?> Tk</td>
                                                                <td class="p-1 text-right text-nowrap"><?php echo e($item->total_price); ?> Tk</td>
                                                                <td><td>
                                                            </tr>
                                                        <?php endif; ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php else: ?>
                                                <?php endif; ?>
                                                <tr></tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php else: ?>
                                            <?php $__currentLoopData = $search; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr class="text-center">
                                                    <td><?php echo e($order->invoice_no); ?></td>
                                                    
                                                    <td><?php echo e(date('d M Y', strtotime($order->updated_at))); ?></td>
                                                     <td><?php if(isset($order->customer->code)): ?><?php echo e($order->customer->code); ?><?php endif; ?></td>
                                                     <td><?php if(isset($order->customer_name)): ?><?php echo e($order->customer_name); ?><?php endif; ?></td>
                                                     <td><?php if(isset($order->customer_mobile)): ?><?php echo e($order->customer_mobile); ?><?php endif; ?></td>
                                                    <td colspan="text-right"><?php echo e($order->total_amount); ?></td>

                                                    <td class="text-center">
                                                        <a href="<?php echo e(route('invoice.admin', $order->id)); ?>"
                                                            class="btn btn-edit"><i class="fas fa-eye"></i></a>
                                                        <a href="<?php echo e(route('order.cancel', $order->id)); ?>"
                                                            class="btn btn-delete"><i class="fa fa-trash"></i></a>
                                                    </td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                           
                                        <?php endif; ?>
                                    <?php else: ?>
                                        <tr>
                                            <td class="w-100 text-center py-2" colspan="8">
                                                No Result Found
                                            </td>
                                        </tr>
                                    <?php endif; ?>
                                  
                                </tbody>
                                <thead class="text-center bg-light">
                                    <tr>
                                        <th class="text-end" colspan="5">Total Delivery</th>
                                        <th class="text-nowrap text-start" colspan="2">= <?php echo e($total); ?></th>
                                    </tr>
                                </thead>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\androidApp (6)\resources\views/admin/order/sales.blade.php ENDPATH**/ ?>